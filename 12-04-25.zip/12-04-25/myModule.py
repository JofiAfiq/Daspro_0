import myModule as mod
mod.greeting("Sarah")

pet = mod.kucing["nama"]
print(pet)